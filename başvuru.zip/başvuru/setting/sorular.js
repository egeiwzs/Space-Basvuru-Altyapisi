module.exports = {

    soru1: "İSMİN VE YAŞIN",
    cevap1: "",

    soru2: "AKTİFLİK SÜREN",
    cevap2: "",

    soru3: "SUNUCUDA NELER YAPABİLİRSİN",
    cevap3: "",

    soru4: "DAHA ÖNCE YETKİLİ OLDUĞUN SUNUCULAR",
    cevap4: "",

    soru5: "NEDEN BİZİ TERCİH EDİYORSUN ?",
    cevap5: ""

}

