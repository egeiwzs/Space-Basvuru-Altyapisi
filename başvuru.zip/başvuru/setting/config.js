module.exports = {
    token: "", 
    prefix: "başvuru!",
    Footer: "Space",
    guildID: "1402728400988274840",
    basvuruYt: "1402943315757764639",
    yetkiRolleri: "1403078027063066715",
    logKanalı: "1403458171040960593",
    basvuruDurum: "1402960963543629896"
}

